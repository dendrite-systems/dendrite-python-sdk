from typing import Literal


Status = Literal["success", "failed"]
