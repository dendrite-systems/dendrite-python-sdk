from dendrite_python_sdk.exceptions.DendriteException import DendriteException


class IncorrectOutcomeException(DendriteException):
    pass
